// Point this at your backend. During local dev this is usually
// http://localhost:5000. After deploying the backend (Render/Railway/Heroku),
// replace it with that service's public URL.
const API_BASE_URL = "http://localhost:5000/api";
