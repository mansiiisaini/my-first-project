document.getElementById("year").textContent = new Date().getFullYear();

/* ---------------- Hero console ---------------- */

function consoleLine(text, className = "") {
  const body = document.getElementById("console-body");
  const line = document.createElement("div");
  line.className = `console-line ${className}`.trim();
  line.textContent = text;
  body.appendChild(line);
}

async function runStatusCheck() {
  const started = performance.now();
  try {
    const res = await fetch(`${API_BASE_URL}/status`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const ms = Math.round(performance.now() - started);

    consoleLine(`> connected in ${ms}ms`, "info");
    consoleLine(`> status: ${data.status}`);
    consoleLine(`> database: ${data.db}`);
    consoleLine(`> projects_loaded: ${data.projectCount}`);
    consoleLine(`> skills_loaded: ${data.skillCount}`);
    consoleLine(`> server_uptime: ${data.uptimeSeconds}s`, "info");
  } catch (err) {
    consoleLine("> connection failed", "err");
    consoleLine(`> could not reach ${API_BASE_URL}`, "err");
    consoleLine("> start the backend, or update js/config.js", "info");
  } finally {
    const cursor = document.createElement("span");
    cursor.className = "cursor";
    document.getElementById("console-body").appendChild(cursor);
  }
}

/* ---------------- Skills ---------------- */

const CATEGORY_LABELS = {
  frontend: "Frontend",
  backend: "Backend",
  database: "Database",
  tools: "Tools",
};

async function loadSkills() {
  const board = document.getElementById("skills-board");
  try {
    const res = await fetch(`${API_BASE_URL}/skills`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const skills = await res.json();

    if (!skills.length) {
      board.innerHTML = `<p class="muted">No skills yet — run <code>npm run seed</code> in /backend to add sample data.</p>`;
      return;
    }

    const grouped = skills.reduce((acc, skill) => {
      acc[skill.category] = acc[skill.category] || [];
      acc[skill.category].push(skill);
      return acc;
    }, {});

    board.innerHTML = Object.entries(grouped)
      .map(([category, items]) => {
        const chips = items
          .map((s) => `<span class="skill-chip">${escapeHtml(s.name)}</span>`)
          .join("");
        return `
          <div class="skill-group">
            <h3>${CATEGORY_LABELS[category] || category}</h3>
            <div class="skill-chip-row">${chips}</div>
          </div>`;
      })
      .join("");
  } catch (err) {
    board.innerHTML = `<p class="muted">Couldn't load skills right now — the API may be offline.</p>`;
  }
}

/* ---------------- Projects ---------------- */

async function loadProjects() {
  const grid = document.getElementById("project-grid");
  try {
    const res = await fetch(`${API_BASE_URL}/projects`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const projects = await res.json();

    if (!projects.length) {
      grid.innerHTML = `<p class="muted">No projects yet — run <code>npm run seed</code> in /backend to add sample data.</p>`;
      return;
    }

    grid.innerHTML = projects.map(renderProjectCard).join("");
  } catch (err) {
    grid.innerHTML = `<p class="muted">Couldn't load projects right now — the API may be offline.</p>`;
  }
}

function renderProjectCard(project) {
  const stack = (project.stack || [])
    .map((tech) => `<span class="stack-pill">${escapeHtml(tech)}</span>`)
    .join("");

  const links = [
    project.repoUrl ? `<a href="${escapeAttr(project.repoUrl)}" target="_blank" rel="noopener">Code →</a>` : "",
    project.liveUrl ? `<a href="${escapeAttr(project.liveUrl)}" target="_blank" rel="noopener">Live →</a>` : "",
  ].join("");

  return `
    <div class="project-card">
      ${project.featured ? '<span class="featured-tag">Featured</span>' : ""}
      <h3>${escapeHtml(project.title)}</h3>
      <p>${escapeHtml(project.description)}</p>
      <div class="stack-row">${stack}</div>
      <div class="project-links">${links}</div>
    </div>`;
}

/* ---------------- Contact form ---------------- */

document.getElementById("contact-form").addEventListener("submit", async (e) => {
  e.preventDefault();

  const form = e.target;
  const statusEl = document.getElementById("form-status");
  const submitBtn = document.getElementById("contact-submit");

  const payload = {
    name: form.name.value.trim(),
    email: form.email.value.trim(),
    message: form.message.value.trim(),
  };

  if (!payload.name || !payload.email || !payload.message) {
    statusEl.textContent = "Please fill in every field.";
    statusEl.className = "form-status err";
    return;
  }

  submitBtn.disabled = true;
  submitBtn.textContent = "Sending…";
  statusEl.textContent = "";
  statusEl.className = "form-status";

  try {
    const res = await fetch(`${API_BASE_URL}/contact`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.error || `HTTP ${res.status}`);
    }

    statusEl.textContent = "Message sent — thanks! I'll reply soon.";
    statusEl.className = "form-status ok";
    form.reset();
  } catch (err) {
    statusEl.textContent = `Couldn't send that: ${err.message}`;
    statusEl.className = "form-status err";
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = "Send message";
  }
});

/* ---------------- Helpers ---------------- */

function escapeHtml(str = "") {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function escapeAttr(str = "") {
  return str.replace(/"/g, "&quot;");
}

/* ---------------- Init ---------------- */

runStatusCheck();
loadSkills();
loadProjects();
