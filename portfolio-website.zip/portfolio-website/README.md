# Personal Portfolio Website

A full-stack portfolio: a plain HTML/CSS/JS frontend, an Express REST API, and a MongoDB database.
The hero includes a live "console" panel that pings the real API on page load, so the site
itself proves the stack is wired together.

```
portfolio-website/
├── backend/          Express API + MongoDB (Mongoose)
│   ├── models/        Project, Skill, Message schemas
│   ├── routes/        /api/projects, /api/skills, /api/contact, /api/status
│   ├── config/db.js    Mongo connection
│   ├── seed.js         Populates sample projects/skills
│   └── server.js
└── frontend/         Static site — no build step
    ├── index.html
    ├── css/style.css
    └── js/{config.js, main.js}
```

## 1. Prerequisites

- Node.js 18+
- A MongoDB database — either:
  - **Local**: install MongoDB Community Server, or run it in Docker: `docker run -d -p 27017:27017 mongo`
  - **Cloud (recommended, free tier)**: [MongoDB Atlas](https://www.mongodb.com/cloud/atlas/register) — create a free cluster, add a database user, and copy the connection string.

## 2. Run the backend locally

```bash
cd backend
npm install
cp .env.example .env
# edit .env: set MONGO_URI to your local or Atlas connection string
npm run seed     # loads sample projects & skills
npm run dev      # starts the API on http://localhost:5000
```

Visit `http://localhost:5000/api/status` — you should see JSON with `"status": "online"`.

## 3. Run the frontend locally

The frontend is static, so any local server works. From the `frontend/` folder:

```bash
npx serve .
# or: python3 -m http.server 8080
```

Open the URL it gives you. `js/config.js` already points at `http://localhost:5000/api`,
matching the backend's default port, so the console panel, skills, and projects should load
immediately. If they say "API may be offline", make sure the backend is running first.

## 4. Make it yours

- Edit the name, headline, and about copy directly in `frontend/index.html`.
- Edit `backend/seed.js` with your real projects and skills, then re-run `npm run seed`.
- Update the social links in the footer of `index.html`.
- Swap the Google Fonts link or CSS tokens in `css/style.css` if you want a different look —
  all colors and fonts are defined as CSS variables at the top of the file.

## 5. Deploy

Deploy the three pieces independently — this is the standard pattern for a decoupled
frontend/backend app.

### Database — MongoDB Atlas
Already covered in step 1 if you used Atlas. Under **Network Access**, allow access from
anywhere (`0.0.0.0/0`) or your hosting provider's IP range so your deployed backend can reach it.

### Backend — Render (or Railway / Heroku)
Using [Render](https://render.com) (free tier, no credit card):
1. Push this repo to GitHub.
2. New → Web Service → connect the repo, set **Root Directory** to `backend`.
3. Build command: `npm install`. Start command: `npm start`.
4. Add environment variables: `MONGO_URI` (your Atlas string), `CORS_ORIGIN` (your frontend's
   deployed URL, added after step below — you can update it later), `PORT` is set automatically.
5. Deploy. Note the public URL, e.g. `https://your-api.onrender.com`.

Railway and Heroku work the same way — set the root/working directory to `backend`, the same
build/start commands, and the same environment variables.

### Frontend — Netlify or Vercel
1. Edit `frontend/js/config.js` and set `API_BASE_URL` to your deployed backend, e.g.
   `https://your-api.onrender.com/api`.
2. **Netlify**: drag-and-drop the `frontend` folder onto [app.netlify.com/drop](https://app.netlify.com/drop),
   or connect the repo and set **Base directory** to `frontend` with an empty build command.
3. **Vercel**: `vercel --cwd frontend` (via the Vercel CLI), or import the repo in the dashboard
   and set **Root Directory** to `frontend`, framework preset "Other".
4. Once deployed, copy the frontend's URL and set it as `CORS_ORIGIN` in your backend's
   environment variables (Render/Railway/Heroku dashboard), then redeploy the backend so it
   accepts requests from your live site.

### Verify
Open your deployed frontend URL — the hero console should show `connected in Nms` and real
project/skill counts pulled live from your database.

## API reference

| Method | Route             | Description                          |
|--------|-------------------|---------------------------------------|
| GET    | `/api/status`     | Health check + live counts (for the hero console) |
| GET    | `/api/projects`   | List all projects |
| POST   | `/api/projects`   | Create a project |
| PUT    | `/api/projects/:id` | Update a project |
| DELETE | `/api/projects/:id` | Delete a project |
| GET    | `/api/skills`     | List all skills |
| POST   | `/api/skills`     | Create a skill |
| PUT    | `/api/skills/:id` | Update a skill |
| DELETE | `/api/skills/:id` | Delete a skill |
| POST   | `/api/contact`    | Submit the contact form (stored in MongoDB) |
| GET    | `/api/contact`    | List submitted messages |

There's no authentication on the write routes in this starter — treat `/api/projects`,
`/api/skills`, and `GET /api/contact` as admin-only and don't expose them publicly if you
deploy as-is. Adding a simple API key or JWT check on those routes is a natural next step.
