// Populates the database with sample data so the site isn't empty on first run.
// Run with: npm run seed
require("dotenv").config();
const mongoose = require("mongoose");
const Project = require("./models/Project");
const Skill = require("./models/Skill");

const projects = [
  {
    title: "Personal Portfolio Website",
    description:
      "This site. A full-stack portfolio with an Express + MongoDB API behind a plain HTML/CSS/JS frontend, including a live status readout in the hero.",
    stack: ["HTML", "CSS", "JavaScript", "Node.js", "Express", "MongoDB"],
    repoUrl: "https://github.com/yourname/portfolio-website",
    liveUrl: "",
    featured: true,
    order: 0,
  },
  {
    title: "Task Tracker API",
    description:
      "A REST API for managing tasks with due dates and priority levels, including JWT authentication and role-based access.",
    stack: ["Node.js", "Express", "MongoDB", "JWT"],
    repoUrl: "https://github.com/yourname/task-tracker-api",
    liveUrl: "",
    featured: true,
    order: 1,
  },
  {
    title: "Weather Dashboard",
    description:
      "A responsive dashboard that pulls live weather data from a public API and caches results to stay within rate limits.",
    stack: ["JavaScript", "Chart.js", "Express"],
    repoUrl: "https://github.com/yourname/weather-dashboard",
    liveUrl: "",
    featured: false,
    order: 2,
  },
];

const skills = [
  { name: "HTML5", category: "frontend", level: 5, order: 0 },
  { name: "CSS3", category: "frontend", level: 5, order: 1 },
  { name: "JavaScript", category: "frontend", level: 4, order: 2 },
  { name: "React", category: "frontend", level: 3, order: 3 },
  { name: "Node.js", category: "backend", level: 4, order: 0 },
  { name: "Express", category: "backend", level: 4, order: 1 },
  { name: "REST API design", category: "backend", level: 4, order: 2 },
  { name: "MongoDB", category: "database", level: 4, order: 0 },
  { name: "Mongoose", category: "database", level: 4, order: 1 },
  { name: "PostgreSQL", category: "database", level: 2, order: 2 },
  { name: "Git", category: "tools", level: 4, order: 0 },
  { name: "Docker", category: "tools", level: 2, order: 1 },
];

async function seed() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("Connected. Seeding data...");

    await Project.deleteMany({});
    await Skill.deleteMany({});

    await Project.insertMany(projects);
    await Skill.insertMany(skills);

    console.log(`Inserted ${projects.length} projects and ${skills.length} skills.`);
  } catch (err) {
    console.error("Seed failed:", err.message);
  } finally {
    await mongoose.disconnect();
  }
}

seed();
