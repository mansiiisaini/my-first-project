const express = require("express");
const Message = require("../models/Message");

const router = express.Router();

// POST /api/contact - store a message sent from the contact form
router.post("/", async (req, res) => {
  try {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({ error: "name, email, and message are all required" });
    }

    const saved = await Message.create({ name, email, message });
    res.status(201).json({ success: true, id: saved._id });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// GET /api/contact - list messages (simple inbox view, no auth in this starter)
router.get("/", async (req, res) => {
  try {
    const messages = await Message.find().sort({ createdAt: -1 });
    res.json(messages);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch messages" });
  }
});

module.exports = router;
