const express = require("express");
const mongoose = require("mongoose");
const Project = require("../models/Project");
const Skill = require("../models/Skill");

const router = express.Router();

// GET /api/status - lightweight system status used by the frontend's
// live "console" panel to prove the full stack is actually connected.
router.get("/status", async (req, res) => {
  try {
    const [projectCount, skillCount] = await Promise.all([
      Project.countDocuments(),
      Skill.countDocuments(),
    ]);

    res.json({
      status: "online",
      db: mongoose.connection.readyState === 1 ? "connected" : "disconnected",
      projectCount,
      skillCount,
      uptimeSeconds: Math.floor(process.uptime()),
      serverTime: new Date().toISOString(),
    });
  } catch (err) {
    res.status(500).json({ status: "error", error: err.message });
  }
});

module.exports = router;
