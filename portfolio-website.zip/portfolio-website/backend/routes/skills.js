const express = require("express");
const Skill = require("../models/Skill");

const router = express.Router();

// GET /api/skills - list all skills, grouped-friendly (sorted by category then order)
router.get("/", async (req, res) => {
  try {
    const skills = await Skill.find().sort({ category: 1, order: 1 });
    res.json(skills);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch skills" });
  }
});

// POST /api/skills - create a skill
router.post("/", async (req, res) => {
  try {
    const skill = await Skill.create(req.body);
    res.status(201).json(skill);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT /api/skills/:id - update a skill
router.put("/:id", async (req, res) => {
  try {
    const skill = await Skill.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!skill) return res.status(404).json({ error: "Skill not found" });
    res.json(skill);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE /api/skills/:id - remove a skill
router.delete("/:id", async (req, res) => {
  try {
    const skill = await Skill.findByIdAndDelete(req.params.id);
    if (!skill) return res.status(404).json({ error: "Skill not found" });
    res.json({ success: true });
  } catch (err) {
    res.status(400).json({ error: "Invalid skill id" });
  }
});

module.exports = router;
